import { useState } from 'react';

const trainingPlan = {
  push: [
    { name: "Panca piana con bilanciere", sets: 4, reps: "6-8" },
    { name: "Panca inclinata con manubri", sets: 3, reps: "8-10" },
    { name: "Chest press o croci ai cavi", sets: 3, reps: "10-12" },
    { name: "Military press bilanciere", sets: 4, reps: "6-8" },
    { name: "Alzate laterali", sets: 3, reps: "12-15" },
    { name: "French press", sets: 3, reps: "10" },
    { name: "Pushdown cavo o corda", sets: 3, reps: "12-15" },
  ],
  schiena: [
    { name: "Stacco da terra", sets: 4, reps: "5" },
    { name: "Trazioni", sets: 4, reps: "max" },
    { name: "Rematore", sets: 3, reps: "8-10" },
    { name: "Lat machine inversa", sets: 3, reps: "10-12" },
    { name: "Curl bilanciere EZ", sets: 3, reps: "10" },
    { name: "Hammer curl", sets: 3, reps: "12" },
    { name: "Curl concentrazione", sets: 2, reps: "12-15" },
  ],
  gambe: [
    { name: "Squat", sets: 4, reps: "6-8" },
    { name: "Leg press", sets: 3, reps: "10" },
    { name: "Affondi camminati", sets: 3, reps: "12/gamba" },
    { name: "Leg curl", sets: 3, reps: "12" },
    { name: "Calf raise", sets: 3, reps: "15-20" },
    { name: "Crunch", sets: 3, reps: "20" },
    { name: "Plank", sets: 3, reps: "1 min" },
  ],
  spalle: [
    { name: "Shoulder press manubri", sets: 4, reps: "8" },
    { name: "Alzate posteriori", sets: 3, reps: "12" },
    { name: "Arnold press", sets: 3, reps: "10" },
    { name: "Curl bilanciere", sets: 3, reps: "10" },
    { name: "Curl panca inclinata", sets: 3, reps: "12" },
    { name: "Pushdown corda", sets: 3, reps: "12" },
    { name: "Estensioni sopra testa", sets: 3, reps: "12" },
  ]
};

export default function WorkoutApp() {
  const [selectedDay, setSelectedDay] = useState('push');
  const [weights, setWeights] = useState({});

  const handleChange = (exercise, value) => {
    setWeights({ ...weights, [exercise]: value });
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Scheda Allenamento (4 giorni)</h1>
      <div style={{ marginBottom: '20px' }}>
        {Object.keys(trainingPlan).map((day) => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            style={{
              marginRight: '10px',
              padding: '10px',
              backgroundColor: selectedDay === day ? '#007bff' : '#ccc',
              color: 'white',
              border: 'none',
              borderRadius: '5px'
            }}
          >
            {day}
          </button>
        ))}
      </div>
      <div>
        {trainingPlan[selectedDay].map((ex, i) => (
          <div key={i} style={{ marginBottom: '15px' }}>
            <strong>{ex.name}</strong><br />
            <small>{ex.sets} serie x {ex.reps} ripetizioni</small><br />
            <input
              type="text"
              placeholder="Carico usato (kg)"
              value={weights[ex.name] || ''}
              onChange={(e) => handleChange(ex.name, e.target.value)}
              style={{ padding: '5px', marginTop: '5px', width: '200px' }}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
